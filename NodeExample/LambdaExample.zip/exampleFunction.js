/**
 * Created by carlos.gonzalez on 3/3/17.
 */

var printHello = function () {
    console.log("Funcion importada");

}
exports.printHello = printHello;